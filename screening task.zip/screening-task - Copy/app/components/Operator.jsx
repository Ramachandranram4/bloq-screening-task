'use client';

import React, { useState } from 'react';
import { margin, size } from '../data/operators.jsx';
import { Eye } from 'lucide-react';

export default function Operator({
  title,
  itemId,
  fill,
  height,
  width,
  components = [],
  isCustom,
  symbol,
  style = {},
  layout = [],
  x = 0,
  y = 0,
}) {
  const [isXRayMode, setIsXRayMode] = useState(false);

  const minX = Math.min(...components.map(c => c.x));
  const maxX = Math.max(...components.map(c => c.x));

  const gateWidth = isXRayMode
    ? (maxX - minX + 1) * (size + margin.x) - margin.x
    : size;

  const gateHeight = height * size + (height - 1) * margin.y;

  // Overlap check for X-ray expansion
  const handleToggleXRay = (e) => {
    e.stopPropagation();
    if (!isXRayMode) {
      const expandedWidth = maxX - minX + 1;
      const expandedHeight = height;

      // Check for overlap in the layout
      const overlap = layout.some(item => {
        if (item.i === itemId) return false;
        // Check if rows overlap
        const rowsOverlap =
          item.y < y + expandedHeight &&
          y < item.y + (item.h || 1);
        // Check if columns overlap
        const colsOverlap =
          item.x < x + expandedWidth &&
          x < item.x + (item.w || 1);
        return rowsOverlap && colsOverlap;
      });
      if (overlap) {
        alert('Cannot expand: overlap with another gate!');
        return;
      }
    }
    setIsXRayMode(!isXRayMode);
  };

  return (
    <div style={{ ...style }} className="group relative">
      <svg
        className={`absolute top-0 left-0 z-40 transition-all`}
        height={gateHeight}
        width={gateWidth}
        overflow="visible"
        xmlns="http://www.w3.org/2000/svg"
      >
        <rect
          fill={isXRayMode ? '#3b82f640' : fill}
          height={gateHeight}
          width={gateWidth}
          rx="8"
          ry="8"
          x="0"
          y="0"
        />

        {!isXRayMode && symbol}

        {isXRayMode &&
          components.map((comp, idx) => {
            const cx = (comp.x - minX) * (size + margin.x);
            const cy = comp.y * (size + margin.y);
            return (
              <g key={idx} transform={`translate(${cx}, ${cy})`}>
                <rect
                  x={0}
                  y={0}
                  width={size}
                  height={size}
                  rx={6}
                  fill="red"
                />
                <text
                  x={size / 2}
                  y={size / 2}
                  dominantBaseline="middle"
                  textAnchor="middle"
                  fontSize="16"
                  fontFamily="'Arial Black', Arial, sans-serif"
                  fill="white"
                >
                  H
                </text>
              </g>
            );
          })}
      </svg>

      {isCustom && (
        <button
          aria-label="Toggle X-Ray Mode"
          className={`absolute -top-2 -left-2 bg-white border border-gray-300 rounded-full shadow cursor-pointer z-50 p-[1px] hover:scale-105 transition-transform ${!isXRayMode ? 'group-hover:block hidden' : ''}`}
          onClick={handleToggleXRay}
        >
          <Eye size={14} color={isXRayMode ? 'deepskyblue' : 'black'} />
        </button>
      )}
    </div>
  );
}