import ReactGridLayout from 'react-grid-layout';
import React, { useEffect } from 'react';
import Operator from './Operator';
import { margin, operators, size } from '../data/operators';

const circuitContainerPadding = {
    x: 0,
    y: 0,
};
const containerPadding = {
    x: 10,
    y: 10,
};
const circuitLineMarginL = 40;
const circuitLineMarginR = 50;
const gridDimenY = 3;
const gridDimenX = 10;

export default ({ droppingItem }) => {
    const [layout, setLayout] = React.useState([]);
    const [droppingItemHeight, setDroppingItemHeight] = React.useState(1);
    const [droppingItemWidth, setDroppingItemWidth] = React.useState(1);
    const [draggedItemId, setDraggedItemId] = React.useState(null);

    // Set dropping item height and width for placeholder
    useEffect(() => {
        if (!droppingItem) return;
        const op = operators.find(op => op.id === droppingItem);
        setDroppingItemHeight(op?.height ?? 1);
        setDroppingItemWidth(op?.width ?? 1);
    }, [droppingItem]);

    const handleCircuitChange = (newCircuit) => {
        setLayout(newCircuit.layout);
    };

    // Prevent overlap when dropping a new gate
    const onDrop = (newLayout, layoutItem, event) => {
        event.preventDefault();

        const gateId = event.dataTransfer.getData('gateId');
        const gate = operators.find(op => op.id === gateId);
        const height = gate?.height || 1;
        const width = gate?.width || 1;

        if (layoutItem.y + height > gridDimenY) {
            return; // Prevent dropping if gate exceeds grid height
        }

       const willOverlap = layout.some(item => {
    // Check if rows overlap
    const rowsOverlap = (
        item.y < layoutItem.y + height &&
        layoutItem.y < item.y + item.h
    );
    // Check if columns overlap
    const colsOverlap = (
        item.x < layoutItem.x + width &&
        layoutItem.x < item.x + item.w
    );
    return rowsOverlap && colsOverlap;
});
if (willOverlap) {
    // Prevent drop if overlap detected
    return;
}

        const newItem = {
            i: new Date().getTime().toString(),
            gateId: gateId,
            x: layoutItem.x,
            y: layoutItem.y,
            w: width, // updated for varying width
            h: height,
            isResizable: false,
        };

        const updatedLayout = newLayout
            .filter(item => item.i !== '__dropping-elem__' && item.y < gridDimenY)
            .map(item => ({
                ...item,
                gateId: layout.find(i => i.i === item.i)?.gateId,
            }));
        updatedLayout.push(newItem);

        handleCircuitChange({ layout: updatedLayout });
        return;
    };

    const handleDragStop = (newLayout) => {
        if (!draggedItemId) {
            console.error('Dragged item ID is missing on drag stop!');
            return;
        }
        const updatedLayout = newLayout
            .filter(item => item.i !== '__dropping-elem__' && item.y < gridDimenY)
            .map(item => ({
                ...item,
                gateId: layout.find(i => i.i === item.i)?.gateId,
            }));
        setLayout(updatedLayout);
        setDraggedItemId(null);
    };

    return (
        <div
            className='relative bg-white border-2 border-gray-200 m-2 shadow-lg rounded-lg'
            style={{
                boxSizing: 'content-box',
                padding: `${circuitContainerPadding.y}px ${circuitContainerPadding.x}px`,
                minWidth: `${2 * containerPadding.x + gridDimenX * (size + margin.x)}px`,
                width: `${2 * containerPadding.x + gridDimenX * (size + margin.x) + size / 2 + margin.x}px`,
                height: `${2 * containerPadding.y + gridDimenY * (size + margin.y) - margin.y}px`,
                overflow: 'hidden',
            }}
        >
            <ReactGridLayout
                allowOverlap={false}
                layout={layout}
                useCSSTransforms={false}
                className="relative z-20"
                cols={gridDimenX}
                compactType={null}
                containerPadding={[containerPadding.x, containerPadding.y]}
                droppingItem={{
                    i: '__dropping-elem__',
                    h: droppingItemHeight,
                    w: droppingItemWidth, // updated
                }}
                isBounded={false}
                isDroppable={true}
                margin={[margin.x, margin.y]}
                onDrag={() => {
                    const placeholderEl = document.querySelector('.react-grid-placeholder');
                    if (placeholderEl) {
                        placeholderEl.style.backgroundColor = 'rgba(235, 53, 53, 0.2)';
                        placeholderEl.style.border = '2px dashed blue';
                    }
                }}
                onDragStart={(layout, oldItem) => {
                    const draggedItemId = oldItem?.i;
                    if (!draggedItemId) {
                        console.error('Dragged item ID is missing!');
                        return;
                    }
                    setDraggedItemId(draggedItemId);
                }}
                onDragStop={(layout) => handleDragStop(layout)}
                onDrop={onDrop}
                preventCollision={true}
                rowHeight={size}
                style={{
                    minHeight: `${2 * containerPadding.y + gridDimenY * (size + margin.y) - margin.y}px`,
                    maxHeight: `${2 * containerPadding.y + gridDimenY * (size + margin.y) - margin.y}px`,
                    overflowY: 'visible',
                    marginLeft: `${circuitLineMarginL}px`,
                    marginRight: `${circuitLineMarginR}px`,
                }}
                width={gridDimenX * (size + margin.x)}
            >
                {layout?.map((item) => {
                    const gate = operators.find(op => op.id === item.gateId);
                    if (!gate) {
                        console.warn(`Gate with ID ${item.gateId} not found in operators.`);
                        return null;
                    }
                    return (
                        <div
                            className="grid-item relative group"
                            data-grid={item}
                            key={item.i}
                        >
                            <Operator
  itemId={item.i}
  symbol={gate.icon}
  height={gate.height}
  width={gate.width}
  fill={gate.fill}
  isCustom={gate.isCustom}
  components={gate.components ?? []}
  layout={layout}
  x={item.x} // <-- pass x
  y={item.y} // <-- pass y
/>
                        </div>
                    );
                })}
            </ReactGridLayout>

            <div
                className="absolute top-0 left-0 z-10"
                style={{
                    width: `${2 * containerPadding.x + gridDimenX * (size + margin.x) + size / 2}px`,
                }}
            >
                {[...new Array(gridDimenY)].map((_, index) => (
                    <div
                        className={'absolute flex group'}
                        key={index}
                        style={{
                            height: `${size}px`,
                            width: '100%',
                            top: `${circuitContainerPadding.y + containerPadding.y + index * size + size / 2 + index * margin.y}px`,
                            paddingLeft: `${circuitLineMarginL}px`,
                        }}
                    >
                        <div className="absolute top-0 -translate-y-1/2 left-2 font-mono">
                            Q<sub>{index}</sub>
                        </div>
                        <div
                            className="h-[1px] bg-gray-400 grow"
                            data-line={index}
                            data-val={index + 1}
                        ></div>
                    </div>
                ))}
            </div>
        </div>
    );
};